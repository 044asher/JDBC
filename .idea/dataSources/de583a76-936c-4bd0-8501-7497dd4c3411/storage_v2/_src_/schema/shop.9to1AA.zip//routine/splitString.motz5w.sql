create
    definer = root@localhost procedure splitString(IN input varchar(255))
BEGIN
    DECLARE temp VARCHAR(255);
    DECLARE result VARCHAR(255);

    SET temp = input;
    SET result = NULL;

    WHILE LENGTH(temp) > 0 DO
        SET result = IFNULL(CONCAT(result, SUBSTRING_INDEX(temp, ',', 1)), result);
        SET temp = SUBSTRING(temp, LENGTH(SUBSTRING_INDEX(temp, ',', 1)) + 2);
    END WHILE;

    SELECT TRIM(result) AS result;
END;

